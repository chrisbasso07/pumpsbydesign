from flask import Flask, render_template, request

app = Flask(__name__)

import math

def calculate_wet_well(flow_gpm, peak_factor, static_head, friction_loss, starts_per_hour, diameter_inches):
    peak_flow = flow_gpm * peak_factor
    tdh = static_head + friction_loss
    pump_capacity = peak_flow  # Assuming 1:1 match

    cycle_time_min = 60 / starts_per_hour
    gallons_per_cycle = pump_capacity * cycle_time_min

    # Calculate gallons per foot (cylinder volume = πr²h, convert to gallons)
    radius_ft = (diameter_inches / 12) / 2
    gallons_per_foot = math.pi * (radius_ft ** 2) * 7.48  # 7.48 gallons per cubic foot

    working_depth = gallons_per_cycle / gallons_per_foot
    working_volume = gallons_per_cycle

    emergency_volume = working_volume * 1.5  # 50% more as buffer
    emergency_depth = emergency_volume / gallons_per_foot

    return {
        "peak_flow": round(peak_flow, 2),
        "tdh": round(tdh, 2),
        "pump_capacity": round(pump_capacity, 2),
        "working_volume": round(working_volume, 2),
        "working_depth": round(working_depth, 2),
        "emergency_volume": round(emergency_volume, 2),
        "emergency_depth": round(emergency_depth, 2)
    }

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    data = request.form
    result = calculate_wet_well(
        float(data['flow_gpm']),
        float(data['peak_factor']),
        float(data['static_head']),
        float(data['friction_loss']),
        float(data['starts_per_hour']),
        float(data['wetwell_diameter'])
    )
    return render_template('results.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)
