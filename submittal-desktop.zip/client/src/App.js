import React from 'react';
import UploadForm from './components/UploadForm';
import SubmittalList from './components/SubmittalList';
export default function App() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Submittal Package Generator</h1>
      <UploadForm />
      <hr />
      <SubmittalList />
    </div>
  );
}