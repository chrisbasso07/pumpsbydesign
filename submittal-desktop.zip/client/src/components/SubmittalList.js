import React, { useEffect, useState } from 'react';
import axios from 'axios';
export default function SubmittalList() {
  const [items, setItems] = useState([]);
  const [error, setError] = useState('');
  useEffect(() => {
    axios.get('/api/submittals')...
  }, []);
  if (error) return <p style={{ color: 'red' }}>{error}</p>;
  return (...);
}