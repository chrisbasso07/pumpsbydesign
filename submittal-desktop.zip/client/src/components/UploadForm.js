import React, { useState } from 'react';
import axios from 'axios';
export default function UploadForm() {
  const [file, setFile] = useState(null);
  const [csiCode, setCsiCode] = useState('');
  const [error, setError] = useState('');
  async function handleSubmit(e) {
    e.preventDefault();
    if (!file) return setError('Select a file');
    try {
      const form = new FormData();
      form.append('file', file);
      form.append('csiCode', csiCode);
      form.append('metadata', JSON.stringify({ uploadedBy: 'User' }));
      await axios.post('/api/submittals', form);
      window.location.reload();
    } catch (err) {
      setError(err.response?.data?.error || 'Upload failed');
    }
  }
  return (
    <form onSubmit={handleSubmit}>
      <label>CSI Code:<input value={csiCode} onChange={e => setCsiCode(e.target.value)} required /></label>
      <label>File:<input type="file" onChange={e => setFile(e.target.files[0])} required /></label>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <button type="submit">Upload</button>
    </form>
  );
}