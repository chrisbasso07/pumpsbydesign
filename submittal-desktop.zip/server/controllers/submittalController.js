const express = require('express');
const router = express.Router();
const upload = require('../middleware/upload').single('file');
const { Submittal } = require('../models');
const path = require('path');

router.post('/', (req, res) => {
  upload(req, res, async err => {
    if (err) return res.status(500).json({ error: err.message });
    try {
      const { csiCode, metadata } = req.body;
      const file = req.file;
      const meta = typeof metadata === 'string' ? JSON.parse(metadata) : metadata;
      const record = await Submittal.create({ csiCode, filename: file.filename, originalName: file.originalname, metadata: meta });
      res.json(record);
    } catch (e) {
      res.status(400).json({ error: e.message });
    }
  });
});

router.get('/', async (_req, res) => {
  try {
    const list = await Submittal.findAll({ order: [['createdAt', 'DESC']] });
    res.json(list);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/download/:id', async (req, res) => {
  try {
    const rec = await Submittal.findByPk(req.params.id);
    if (!rec) return res.status(404).json({ error: 'Not found' });
    const filePath = path.join(path.resolve(process.env.UPLOAD_DIR), rec.filename);
    return res.download(filePath, rec.originalName);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;