const multer = require('multer');
const path = require('path');
const uploadDir = path.resolve(process.env.UPLOAD_DIR);
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
module.exports = multer({ storage });