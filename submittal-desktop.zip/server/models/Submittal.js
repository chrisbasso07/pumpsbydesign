module.exports = sequelize => {
  const { DataTypes } = require('sequelize');
  return sequelize.define('Submittal', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    csiCode: { type: DataTypes.STRING, allowNull: false },
    filename: { type: DataTypes.STRING, allowNull: false },
    originalName: DataTypes.STRING,
    metadata: { type: DataTypes.JSON, allowNull: false, defaultValue: {} }
  }, { timestamps: true });
};