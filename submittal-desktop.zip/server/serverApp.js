require('dotenv').config();
const express = require('express');
const path = require('path');
const submittalRouter = require('./controllers/submittalController');
const app = express();
app.use(express.json());
app.use('/uploads', express.static(path.resolve(process.env.UPLOAD_DIR)));
app.use('/api/submittals', submittalRouter);
module.exports.start = port => {
  const { sequelize } = require('./models');
  sequelize.sync()
    .then(() => app.listen(port, () => console.log(`Server listening on port ${port}`)))
    .catch(console.error);
};